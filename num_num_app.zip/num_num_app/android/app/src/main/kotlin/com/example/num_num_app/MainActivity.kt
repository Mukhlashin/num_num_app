package com.example.num_num_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
